This archive was created with CARE: http://reproducible.io. It contains:

re-execute.sh
    start the re-execution of the initial command as originally
    specified.  It is also possible to specify an alternate command.
    For example, assuming gcc was archived, it can be re-invoked
    differently:

        $ ./re-execute.sh gcc --version
        gcc (Ubuntu/Linaro 4.5.2-8ubuntu4) 4.5.2

        $ echo 'int main(void) { return puts("OK"); }' > rootfs/foo.c
        $ ./re-execute.sh gcc -Wall /foo.c
        $ foo.c: In function "main":
        $ foo.c:1:1: warning: implicit declaration of function "puts"

rootfs/
    directory where all the files used during the original execution
    were archived, they will be required for the reproduced execution.

proot
    virtualization tool invoked by re-execute.sh to confine the
    reproduced execution into the rootfs.  It also emulates the
    missing kernel features if needed.

concealed-accesses.txt
    list of accessed paths that were concealed during the original
    execution.  Its main purpose is to know what are the paths that
    should be revealed if the the original execution didn't go as
    expected.  It is absolutely useless for the reproduced execution.


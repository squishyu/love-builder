#! /bin/sh

export XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}"
export ICEAUTHORITY="${ICEAUTHORITY:-$HOME/.ICEauthority}"

nbargs=$#
[ $nbargs -ne 0 ] || set -- \
'love' \

PROOT="${PROOT-$(dirname $0)/proot}"

if [ ! -e ${PROOT} ]; then
    PROOT=$(which proot)
fi

if [ -z ${PROOT} ]; then
    echo '**********************************************************************'
    echo '"proot" command not found, please get it from http://proot.me'
    echo '**********************************************************************'
    exit 1
fi

if [ x$PROOT_NO_SECCOMP != x ]; then
    PROOT_NO_SECCOMP="PROOT_NO_SECCOMP=$PROOT_NO_SECCOMP"
fi

env --ignore-environment \
PROOT_IGNORE_MISSING_BINDINGS=1 \
$PROOT_NO_SECCOMP \
'SHELL=/bin/bash'  \
'COLORTERM=truecolor'  \
'XDG_SESSION_PATH=/org/freedesktop/DisplayManager/Session0'  \
'GNOME_DESKTOP_SESSION_ID=this-is-deprecated'  \
'GTK_IM_MODULE=fcitx'  \
'LANGUAGE=en_US'  \
'QT4_IM_MODULE=fcitx'  \
'SSH_AUTH_SOCK=/run/user/1000/keyring/ssh'  \
'XMODIFIERS=@im=fcitx'  \
'DESKTOP_SESSION=deepin'  \
'NO_AT_BRIDGE=1'  \
'XDG_SEAT=seat0'  \
'PWD=/home/matt/Downloads/Dream Inducer'  \
'XDG_SESSION_DESKTOP=deepin'  \
'LOGNAME=matt'  \
'XDG_SESSION_TYPE=x11'  \
'GPG_AGENT_INFO=/run/user/1000/gnupg/S.gpg-agent:0:1'  \
'XAUTHORITY=/home/matt/.Xauthority'  \
'XDG_GREETER_DATA_DIR=/var/lib/lightdm/data/matt'  \
'HOME=/home/matt'  \
'LANG=en_US.UTF-8'  \
'LS_COLORS=bd=38;5;68;1:ca=38;5;17:cd=38;5;132;1:di=38;5;105:do=38;5;127:ex=38;5;80:pi=38;5;126:fi=38;5;167:ln=38;5;63:mh=38;5;99;1:or=48;5;197;38;5;228;1:ow=38;5;220;1:sg=48;5;234;38;5;100;1:su=38;5;9;1:so=38;5;197:st=38;5;86;48;5;234:tw=48;5;235;38;5;139;3:*LS_COLORS=48;5;89;38;5;197;1;3;4;7:*.BAT=38;5;108:*.exe=38;5;196:*.PL=38;5;160:*.asm=38;5;240;1:*.awk=38;5;148;1:*.bash=38;5;173:*.bat=38;5;108:*.c=38;5;110:*.cc=38;5;24;1:*.ii=38;5;24;1:*.cfg=1:*.cl=38;5;204;1:*.coffee=38;5;100;1:*.conf=38;5;221:*.C=38;5;24;1:*.cp=38;5;24;1:*.cpp=38;5;24;1:*.cxx=38;5;24;1:*.c++=38;5;24;1:*.ii=38;5;24;1:*.cs=38;5;74;1:*.css=38;5;91:*.csv=38;5;78:*.ctp=38;5;95:*.diff=48;5;197;38;5;232:*.enc=38;5;192;3:*.eps=38;5;33;1:*.etx=38;5;172:*.ex=38;5;148;1:*.example=38;5;225;1:*.git=38;5;197:*.gitignore=38;5;240:*.go=38;5;111:*.h=38;5;81:*.H=38;5;81:*.hpp=38;5;81:*.hxx=38;5;81:*.h++=38;5;81:*.tcc=38;5;81:*.f=38;5;81:*.for=38;5;81:*.ftn=38;5;81:*.s=38;5;81:*.S=38;5;81:*.sx=38;5;81:*.hi=38;5;240:*.hs=38;5;199;1:*.htm=38;5;125;1:*.html=38;5;9;1:*.info=38;5;101:*.ini=38;5;123:*.java=38;5;142;1:*.jhtm=38;5;125;1:*.js=38;5;42:*.jsm=38;5;42:*.jsm=38;5;42:*.json=38;5;213:*.jsp=38;5;45:*.lisp=38;5;204;1:*.log=38;5;190:*.lua=38;5;34;1:*.m=38;5;130;3:*.mht=38;5;129:*.mm=38;5;130;3:*.M=38;5;130;3:*.map=38;5;58;3:*.markdown=38;5;184:*.md=38;5;184:*.mf=38;5;220;3:*.mfasl=38;5;73:*.mi=38;5;124:*.mkd=38;5;184:*.mtx=38;5;36;3:*.nfo=38;5;220:*.o=38;5;240:*.pacnew=38;5;33:*.patch=48;5;197;38;5;232;1:*.pc=38;5;100:*.pfa=38;5;43:*.pgsql=38;5;222:*.php=38;5;99:*.pl=38;5;214:*.po=38;5;176:*.pot=38;5;206;1:*.plt=38;5;204;1:*.pm=38;5;197;1:*.pod=38;5;172;1:*.py=38;5;41:*.pyc=38;5;245:*.rb=38;5;192:*.rdf=38;5;144:*.rst=38;5;67:*.ru=38;5;142:*.scm=38;5;204;1:*.sed=38;5;130;1:*.sfv=38;5;197:*.sh=38;5;113:*.signature=38;5;206:*.sql=38;5;222:*.srt=38;5;116:*.sty=38;5;58:*.sug=38;5;44:*.t=38;5;28;1:*.tcl=38;5;64;1:*.tdy=38;5;214:*.tex=38;5;172:*.textile=38;5;106:*.tfm=38;5;64:*.tfnt=38;5;140:*.theme=38;5;109:*.txt=38;5;192:*.list=38;5;44:*.save=38;5;240:*.urlview=38;5;85:*.vim=38;5;14:*.vimrc=38;5;13:*.viminfo=38;5;240;1:*.xml=38;5;199:*.yml=38;5;208:*.zsh=38;5;173:*.bashrc=38;5;5:*README=38;5;220;1:*Makefile=38;5;196:*MANIFEST=38;5;243:*pm_to_blib=38;5;240:*.1=38;5;240;1:*.2=38;5;220;1:*.3=38;5;196;1:*.7=38;5;196;1:*.1p=38;5;160:*.3p=38;5;160:*.am=38;5;242:*.in=38;5;242:*.old=38;5;242:*.out=38;5;44;1:*.bmp=38;5;33:*.cdr=38;5;33:*.gif=38;5;33:*.ico=38;5;33:*.jpeg=38;5;33:*.jpg=38;5;33:*.JPG=38;5;33:*.png=38;5;33:*.svg=38;5;33;1:*.xpm=38;5;33:*.32x=38;5;137:*.A64=38;5;82:*.a00=38;5;11:*.a52=38;5;112:*.a64=38;5;82:*.a78=38;5;112:*.adf=38;5;35:*.atr=38;5;213:*.cdi=38;5;124:*.fm2=38;5;35:*.gb=38;5;203:*.gba=38;5;205:*.gbc=38;5;204:*.gel=38;5;83:*.gg=38;5;138:*.ggl=38;5;83:*.j64=38;5;102:*.nds=38;5;199:*.nes=38;5;160:*.rom=38;5;59;1:*.sav=38;5;220:*.sms=38;5;33:*.st=38;5;208;1:*.iso=38;5;9;1:*.nrg=38;5;124:*.qcow=38;5;141:*.VOB=38;5;99:*.IFO=38;5;99:*.BUP=38;5;99:*.MOV=38;5;99:*.3gp=38;5;99:*.3g2=38;5;99:*.asf=38;5;99:*.avi=38;5;99:*.divx=38;5;99:*.f4v=38;5;99:*.flv=38;5;99:*.m2v=38;5;99:*.mkv=38;5;99:*.mov=38;5;99:*.mp4=38;5;99:*.mpg=38;5;99:*.mpeg=38;5;99:*.ogm=38;5;99:*.ogv=38;5;99:*.rmvb=38;5;99:*.sample=38;5;99;1:*.ts=38;5;99:*.vob=38;5;99:*.webm=38;5;99:*.wmv=38;5;99:*.S3M=38;5;69;1:*.aac=38;5;69:*.cue=38;5;69:*.dat=38;5;69:*.dts=38;5;69;1:*.fcm=38;5;69:*.flac=38;5;69;1:*.m3u=38;5;69:*.m3u8=38;5;69:*.m4=38;5;69;3:*.m4a=38;5;69;1:*.mid=38;5;69:*.midi=38;5;69:*.mod=38;5;69:*.mp3=38;5;69:*.oga=38;5;69:*.ogg=38;5;69:*.s3m=38;5;69;1:*.sid=38;5;69;1:*.spl=38;5;69:*.wv=38;5;69:*.wvc=38;5;69:*.ape=38;5;69:*.afm=38;5;58:*.pfb=38;5;58:*.pfm=38;5;58:*.ttf=38;5;66:*.ttc=38;5;66:*.pcf=38;5;65:*.psf=38;5;64:*.bak=38;5;222;1:*.bin=38;5;228:*.pid=38;5;228:*.state=38;5;228:*.swo=38;5;228:*.swp=38;5;228:*.tmp=38;5;228:*.un~=38;5;228:*.zcompdump=38;5;228:*.zwc=38;5;228:*.db=38;5;147:*.dump=38;5;147:*.sqlite=38;5;147:*.typelib=38;5;147:*.7z=38;5;140:*.a=38;5;220:*.apk=38;5;148;3:*.arj=38;5;220:*.bz2=38;5;220:*.deb=38;5;215;1:*.ipk=38;5;220:*.jad=38;5;220:*.jar=38;5;220:*.nth=38;5;220:*.sis=38;5;220:*.part=38;5;220;1:*.r00=38;5;220:*.r01=38;5;220:*.r02=38;5;220:*.r03=38;5;220:*.r04=38;5;220:*.r05=38;5;220:*.r06=38;5;220:*.r07=38;5;220:*.r08=38;5;220:*.r09=38;5;220:*.r10=38;5;220:*.r100=38;5;220:*.r101=38;5;220:*.r102=38;5;220:*.r103=38;5;220:*.r104=38;5;220:*.r105=38;5;220:*.r106=38;5;220:*.r107=38;5;220:*.r108=38;5;220:*.r109=38;5;220:*.r11=38;5;220:*.r110=38;5;220:*.r111=38;5;220:*.r112=38;5;220:*.r113=38;5;220:*.r114=38;5;220:*.r115=38;5;220:*.r116=38;5;220:*.r12=38;5;220:*.r13=38;5;220:*.r14=38;5;220:*.r15=38;5;220:*.r16=38;5;220:*.r17=38;5;220:*.r18=38;5;220:*.r19=38;5;220:*.r20=38;5;220:*.r21=38;5;220:*.r22=38;5;220:*.r25=38;5;220:*.r26=38;5;220:*.r27=38;5;220:*.r28=38;5;220:*.r29=38;5;220:*.r30=38;5;220:*.r31=38;5;220:*.r32=38;5;220:*.r33=38;5;220:*.r34=38;5;220:*.r35=38;5;220:*.r36=38;5;220:*.r37=38;5;220:*.r38=38;5;220:*.r39=38;5;220:*.r40=38;5;220:*.r41=38;5;220:*.r42=38;5;220:*.r43=38;5;220:*.r44=38;5;220:*.r45=38;5;220:*.r46=38;5;220:*.r47=38;5;220:*.r48=38;5;220:*.r49=38;5;220:*.r50=38;5;220:*.r51=38;5;220:*.r52=38;5;220:*.r53=38;5;220:*.r54=38;5;220:*.r99=38;5;220:*.r56=38;5;220:*.r69=38;5;220:*.r58=38;5;220:*.r59=38;5;220:*.r60=38;5;220:*.r61=38;5;220:*.r62=38;5;220:*.r63=38;5;220:*.r64=38;5;220:*.r65=38;5;220:*.r66=38;5;220:*.r67=38;5;220:*.r68=38;5;220:*.r69=38;5;220:*.r69=38;5;220:*.r70=38;5;220:*.r71=38;5;220:*.r72=38;5;220:*.r73=38;5;220:*.r74=38;5;220:*.r75=38;5;220:*.r76=38;5;220:*.r77=38;5;220:*.r78=38;5;220:*.r79=38;5;220:*.r80=38;5;220:*.r81=38;5;220:*.r82=38;5;220:*.r83=38;5;220:*.r84=38;5;220:*.r85=38;5;220:*.r86=38;5;220:*.r87=38;5;220:*.r88=38;5;220:*.r89=38;5;220:*.r90=38;5;220:*.r91=38;5;220:*.r92=38;5;220:*.r99=38;5;220:*.r94=38;5;220:*.r95=38;5;220:*.r96=38;5;220:*.r97=38;5;220:*.r98=38;5;220:*.r99=38;5;220:*.rar=38;5;217;1:*.tar=38;5;222:*.tar.gz=38;5;216:*.tgz=38;5;214;1:*.gz=38;5;224:*.xz=38;5;182:*.zip=38;5;208:*.doc=38;5;190:*.wps=38;5;190:*.docx=38;5;190:*.xls=38;5;190:*.xlsx=38;5;190:*.ppt=38;5;190:*.pptx=38;5;190:*.pdf=38;5;190:*.djvu=38;5;190:*.cbr=38;5;190:*.cbz=38;5;190:*.chm=38;5;190:*.odt=38;5;112:*.ods=38;5;112:*.odp=38;5;112:*.odb=38;5;112:*.allow=38;5;112:*.deny=38;5;203:*.SKIP=38;5;244:*.def=38;5;136:*.directory=38;5;69:*.err=38;5;160;1:*.error=38;5;160;1:*.pi=38;5;126:*.properties=38;5;197;1:*.torrent=38;5;105:*.gp3=38;5;114:*.gp4=38;5;115:*.tg=38;5;99:*.pcap=38;5;29:*.cap=38;5;29:*.dmp=38;5;29:*.service=38;5;81:*@.service=38;5;45:*.socket=38;5;75:*.device=38;5;24:*.mount=38;5;115:*.automount=38;5;114:*.swap=38;5;113:*.target=38;5;73:*.path=38;5;116:*.timer=38;5;111:*.snapshot=38;5;139:*.desktop=38;5;113:*.crdownload=38;5;38:*.crx=38;5;13:'  \
'XDG_CURRENT_DESKTOP=Deepin'  \
'VTE_VERSION=5201'  \
'XDG_SEAT_PATH=/org/freedesktop/DisplayManager/Seat0'  \
'CLUTTER_IM_MODULE=fcitx'  \
'XDG_SESSION_CLASS=user'  \
'IBUS_DISABLE_SNOOPER=1'  \
'TERM=xterm-256color'  \
'USER=matt'  \
'DISPLAY'="$DISPLAY"  \
'QT_DBL_CLICK_DIST=15'  \
'SHLVL=1'  \
'QT_IM_MODULE=fcitx'  \
'XDG_VTNR=1'  \
'XDG_SESSION_ID=2'  \
'QT_LINUX_ACCESSIBILITY_ALWAYS_ON=1'  \
'XDG_RUNTIME_DIR=/run/user/1000'  \
'PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/sbin:/usr/sbin'  \
'GDMSESSION=deepin'  \
'DBUS_SESSION_BUS_ADDRESS'="$DBUS_SESSION_BUS_ADDRESS"  \
'GIO_LAUNCHED_DESKTOP_FILE_PID=4943'  \
'GIO_LAUNCHED_DESKTOP_FILE=/usr/share/applications/deepin-terminal.desktop'  \
'OLDPWD=/home/matt/Downloads'  \
'_=/usr/bin/care'  \
'ICEAUTHORITY=/home/matt/.ICEauthority'  \
"${PROOT-$(dirname $0)/proot}" \
-b "/dev"  \
-b "/proc"  \
-b "/sys"  \
-b "/run/shm"  \
-b "/tmp/.X11-unix"  \
-b "/tmp/.ICE-unix"  \
-b "$XAUTHORITY:/home/matt/.Xauthority"  \
-b "$ICEAUTHORITY:/home/matt/.ICEauthority"  \
-b "/run/dbus/system_bus_socket"  \
-b "/var/tmp/kdecache-$LOGNAME"  \
-k '5.3.0-3-amd64'  \
-w '/home/matt/Downloads/Dream Inducer'  \
-r "$(dirname $0)/rootfs" \
-b "$(dirname $0)/rootfs" \
${1+"$@"}

status=$?
if [ $status -ne 0 ] && [ $nbargs -eq 0 ]; then
echo "care: The reproduced execution didn't return the same exit status as the"
echo "care: original execution.  If it is unexpected, please report this bug"
echo "care: to CARE/PRoot developers:"
echo "care:     * mailing list: reproducible@googlegroups.com; or"
echo "care:     * forum: https://groups.google.com/forum/?fromgroups#!forum/reproducible; or"
echo "care:     * issue tracker: https://github.com/cedric-vincent/PRoot/issues/"
fi

exit $status
